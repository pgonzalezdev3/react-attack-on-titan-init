import './App.css'
import HelloWorld from './assets/components/layout/HelloWorld'



function App() {

  const name = '+++ inserta aquí tu nombre +++'

  return (
    <>
      <HelloWorld name={name} />
    </>
  )
}

export default App
